# STICKY SELLER 🛒

STICKY SELLER is an e-commerce website inspired by Flipkart.  
It provides separate sections for **Men** and **Women**, showcasing sample products like clothing, shoes, watches, and accessories.

---

## 🚀 Live Demo (after hosting on GitHub Pages)
Once hosted, your site will be live at:
```
https://your-username.github.io/stickyseller
```

---

## 📂 Project Structure
```
stickyseller_site/
│── index.html   # Main website file
│── README.md    # Project documentation
```

---

## 🛠 How to Host on GitHub Pages
1. Create a repository on [GitHub](https://github.com).
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Source**, select `main branch / root`.
5. Save → Your website will be live in 1–2 minutes.

---

## ✨ Features
- Flipkart-inspired layout  
- Search bar in the header  
- Separate sections for Men and Women  
- Product cards with images, names, and prices  
- Responsive grid layout  

---

## 📜 License
This project is free to use and modify.
